# todo-api-flask

Professional Flask REST API project using **Flask-RESTX**, JWT auth and SQLite.
Ready to upload to GitHub as a portfolio repo.

## Features
- Flask-RESTX namespaces & automatic Swagger UI
- JWT Authentication (register / login)
- Task CRUD operations (per-user)
- SQLite (file-based) persistence
- Flask-Migrate ready

## Quick start

1. Create a virtual environment and activate it
   ```bash
   python -m venv venv
   source venv/bin/activate  # macOS / Linux
   venv\Scripts\activate     # Windows
   ```
2. Install dependencies
   ```bash
   pip install -r requirements.txt
   ```
3. Create a `.env` file (example provided) and then initialize the database:
   ```bash
   export FLASK_APP=run.py
   flask db init
   flask db migrate -m "initial"
   flask db upgrade
   ```
   Or create the database directly:
   ```python
   from app import create_app
   from app.extensions import db
   app = create_app()
   with app.app_context():
       db.create_all()
   ```
4. Run
   ```bash
   python run.py
   ```
5. Visit Swagger UI at: http://127.0.0.1:5000/

## Project structure
```
todo-api-flask/
├── app/
│   ├── __init__.py
│   ├── config.py
│   ├── extensions.py
│   ├── models.py
│   ├── resources/
│   │   ├── auth.py
│   │   └── tasks.py
│   └── routes.py
├── requirements.txt
├── run.py
├── README.md
└── .gitignore
```

## Notes
- This repo is ready to be extended with Docker, CI, tests, and deployment scripts.
- Feel free to customize the configuration values in `app/config.py` or via environment variables.

## 🐳 Run with Docker

1. Build and start containers:
   ```bash
   docker-compose up --build
   ```

2. Visit the API docs:
   👉 http://127.0.0.1:5000/

3. Stop containers:
   ```bash
   docker-compose down
   ```

Your data (SQLite) is stored in a Docker volume called `sqlite_data`.
