from .resources.auth import ns as auth_ns
from .resources.tasks import ns as tasks_ns
from .extensions import api

def register_routes(app):
    api.init_app(app)
    api.add_namespace(auth_ns, path='/auth')
    api.add_namespace(tasks_ns, path='/tasks')
