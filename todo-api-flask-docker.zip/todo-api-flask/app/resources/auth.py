from flask import request
from flask_restx import Namespace, Resource, fields
from werkzeug.exceptions import BadRequest
from ..extensions import db
from ..models import User
from flask_jwt_extended import create_access_token

ns = Namespace('auth', description='Authentication operations')

register_model = ns.model('Register', {
    'email': fields.String(required=True, description='User email'),
    'password': fields.String(required=True, description='Password')
})

login_model = ns.model('Login', {
    'email': fields.String(required=True, description='User email'),
    'password': fields.String(required=True, description='Password')
})

user_model = ns.model('User', {
    'id': fields.Integer(),
    'email': fields.String()
})

@ns.route('/register')
class Register(Resource):
    @ns.expect(register_model, validate=True)
    @ns.marshal_with(user_model, code=201)
    def post(self):
        data = request.get_json() or {}
        email = data.get('email')
        password = data.get('password')
        if not email or not password:
            raise BadRequest('Email and password are required')
        if User.query.filter_by(email=email).first():
            ns.abort(400, 'User already exists')
        user = User(email=email)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        return user.to_dict(), 201


@ns.route('/login')
class Login(Resource):
    @ns.expect(login_model, validate=True)
    def post(self):
        data = request.get_json() or {}
        email = data.get('email')
        password = data.get('password')
        if not email or not password:
            raise BadRequest('Email and password are required')
        user = User.query.filter_by(email=email).first()
        if not user or not user.check_password(password):
            ns.abort(401, 'Invalid credentials')
        access_token = create_access_token(identity=user.id)
        return {'access_token': access_token, 'user': user.to_dict()}, 200
