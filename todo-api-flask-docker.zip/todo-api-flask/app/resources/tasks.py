from flask import request
from flask_restx import Namespace, Resource, fields
from flask_jwt_extended import jwt_required, get_jwt_identity
from ..models import Task, User
from ..extensions import db

ns = Namespace('tasks', description='Task operations')

task_model = ns.model('Task', {
    'id': fields.Integer(readOnly=True),
    'title': fields.String(required=True, description='Task title'),
    'description': fields.String(),
    'done': fields.Boolean()
})

@ns.route('/')
class TaskList(Resource):
    @ns.marshal_list_with(task_model)
    def get(self):
        tasks = Task.query.all()
        return [t.to_dict() for t in tasks], 200

    @jwt_required()
    @ns.expect(task_model, validate=True)
    @ns.marshal_with(task_model, code=201)
    def post(self):
        user_id = get_jwt_identity()
        data = request.get_json() or {}
        title = data.get('title')
        description = data.get('description', '')
        if not title:
            ns.abort(400, 'Title is required')
        task = Task(title=title, description=description, owner_id=user_id)
        db.session.add(task)
        db.session.commit()
        return task.to_dict(), 201


@ns.route('/<int:id>')
@ns.param('id', 'The task identifier')
class TaskItem(Resource):
    @ns.marshal_with(task_model)
    def get(self, id):
        task = Task.query.get_or_404(id)
        return task.to_dict(), 200

    @jwt_required()
    @ns.expect(task_model, validate=False)
    @ns.marshal_with(task_model)
    def put(self, id):
        user_id = get_jwt_identity()
        task = Task.query.get_or_404(id)
        if task.owner_id != user_id:
            ns.abort(403, 'Not authorized to modify this task')
        data = request.get_json() or {}
        task.title = data.get('title', task.title)
        task.description = data.get('description', task.description)
        if 'done' in data:
            task.done = bool(data.get('done'))
        db.session.commit()
        return task.to_dict(), 200

    @jwt_required()
    def delete(self, id):
        user_id = get_jwt_identity()
        task = Task.query.get_or_404(id)
        if task.owner_id != user_id:
            ns.abort(403, 'Not authorized to delete this task')
        db.session.delete(task)
        db.session.commit()
        return {'message': 'Task deleted'}, 200
