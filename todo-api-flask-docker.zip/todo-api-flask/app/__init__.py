import os
from flask import Flask
from .config import Config
from .extensions import db, migrate, jwt, api
from .routes import register_routes

def create_app(config_object=None):
    app = Flask(__name__)
    env_config = config_object or os.environ.get('FLASK_CONFIG') or Config
    if isinstance(env_config, type):
        app.config.from_object(env_config)
    else:
        app.config.from_mapping(env_config)

    # init extensions
    db.init_app(app)
    migrate.init_app(app, db)
    jwt.init_app(app)
    api.init_app(app)

    # register routes / namespaces
    register_routes(app)

    @app.shell_context_processor
    def make_shell_context():
        from .models import User, Task
        return {'db': db, 'User': User, 'Task': Task}

    return app
